/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package kirimbarang;

/**
 *
 * @author sigma
 */
interface Pembuatan {
    void inputBarang(String pengirim, String penerima, String alamat, double harga, double berat);
    void lihatSementara();
    void hapusBarang(String pengirim);
    void updateBarang(String pengirim, String penerima, String alamat);
    void kirim();
}