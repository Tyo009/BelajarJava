/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kirimbarang;

/**
 *
 * @author sigma
 */
abstract class Transaksi {
     abstract public String getPengirim();
    abstract public String getPenerima();
    abstract public String getAlamat();
    abstract public double getHarga();
    abstract public double getBerat();
    abstract public double getTotal();
}
