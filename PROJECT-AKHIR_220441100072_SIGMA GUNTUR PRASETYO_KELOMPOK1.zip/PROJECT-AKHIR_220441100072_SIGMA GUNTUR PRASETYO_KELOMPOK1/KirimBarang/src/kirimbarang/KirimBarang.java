/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kirimbarang;

/**
 *
 * @author sigma
 */

import java.util.ArrayList;
//Library
import java.util.List;

import java.util.Scanner;


class Menu extends Transaksi{
    private String pengirim;
    private String penerima;
    private String alamat;
    private double harga;
    private double berat;
    private double total;

    public Menu(String pengirim, String penerima, String alamat, double harga, double berat) {
        this.pengirim = pengirim;
        this.penerima = penerima;
        this.alamat = alamat;
        this.harga = harga;
        this.berat = berat;
        this.total = harga * berat;
    }

    @Override
    public String getPengirim() {
        return pengirim;
    }

    @Override
    public String getPenerima() {
        return penerima;
    }

    @Override
    public String getAlamat() {
        return alamat;
    }

    @Override
    public double getHarga() {
        return harga;
    }

    @Override
    public double getBerat() {
        return berat;
    }

    @Override
    public double getTotal() {
        return total;
    }
}

class Kiriman {
    private Menu menu;
    private int kirim;

    public Kiriman(Menu menu, int kirim) {
        this.menu = menu;
        this.kirim = kirim;
    }

    public Menu getMenu() {
        return menu;
    }

    public int getKirim() {
        return kirim;
    }

    public double getHarga() {
        return menu.getTotal() * kirim;
    }
}

class PaketJasa implements Pembuatan {
    private List<Menu> menuList;
    private List<Kiriman> kirimanList;

    public PaketJasa() {
        menuList = new ArrayList<>();
        kirimanList = new ArrayList<>();
    }

    public static void namaJasa() {
        System.out.println("Mboh Ws Sk Karepmu!!!");
    }

    public static void harga() {
        System.out.println("Per KG 12000");
    }

    @Override
    public void inputBarang(String pengirim, String penerima, String alamat, double harga, double berat) {
        Menu menu = new Menu(pengirim, penerima, alamat, harga, berat);
        menuList.add(menu);
        System.out.println("Nama Pengirim " + pengirim + " telah ditambahkan");
        System.out.println("Nama Penerima " + penerima + " telah ditambahkan");
        System.out.println("Nama Alamat" + alamat + "Telah Ditambahkan");
        System.out.println("Berat Barang +" + berat + "Telah Ditambahkan");
    }

    @Override
    public void lihatSementara() {
        if (menuList.isEmpty()) {
            System.out.println("Belum ada data yang dimasukkan");
        } else {
            for (Menu menu : menuList) {
                System.out.println("Nama Pengirim: " + menu.getPengirim());
                System.out.println("Nama Penerima: " + menu.getPenerima());
                System.out.println("Alamat: " + menu.getAlamat());
                System.out.println("Harga Per Kg: " + menu.getHarga());
                System.out.println("Berat: " + menu.getBerat());
                System.out.println("Total: " + menu.getTotal());
                System.out.println("-----------------------------");
            }
        }
    }

    @Override
    public void hapusBarang(String pengirim) {
        boolean found = false;
        for (int i = 0; i < menuList.size(); i++) {
            Menu menu = menuList.get(i);
            if (menu.getPengirim().equalsIgnoreCase(pengirim)) {
                menuList.remove(i);
                found = true;
                System.out.println("Data dengan pengirim " + pengirim + " telah dihapus");
                break;
            }
        }

        if (!found) {
            System.out.println("Data dengan pengirim " + pengirim + " tidak ditemukan");
        }
    }

    @Override
    public void updateBarang(String pengirim, String penerima, String alamat) {
        boolean found = false;
        for (int i = 0; i < menuList.size(); i++) {
            Menu menu = menuList.get(i);
            if (menu.getPengirim().equalsIgnoreCase(pengirim)) {
                menuList.set(i, new Menu(pengirim, penerima, alamat, menu.getHarga(), menu.getBerat()));
                found = true;
                System.out.println("Data dengan pengirim " + pengirim + " telah diperbarui");
                break;
            }
        }

        if (!found) {
            System.out.println("Data dengan pengirim " + pengirim + " tidak ditemukan");
        }
    }

    @Override
    public void kirim() {
        if (menuList.isEmpty()) {
            System.out.println("Tidak ada barang yang akan dikirim");
            return;
        }

        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan jumlah pengiriman: ");
        int jumlahKirim = input.nextInt();

        for (Menu menu : menuList) {
            Kiriman kiriman = new Kiriman(menu, jumlahKirim);
            kirimanList.add(kiriman);
        }

        menuList.clear();
        System.out.println("Barang telah dikirim");
    }
}

public class KirimBarang {
    public static void main(String[] args) {
        PaketJasa paketJasa = new PaketJasa();
        Scanner input = new Scanner(System.in);
        int choice;
        do {
            System.out.println("=================================");
            System.out.println("        MENU KIRIM BARANG        ");
            System.out.println("=================================");
            System.out.println("1. Mode Pengguna");
            System.out.println("2. Mode Admin");
            System.out.println("0. Keluar");
            System.out.print("Pilih mode yang diinginkan: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    modePengguna(paketJasa, input);
                    break;
                case 2:
                    modeAdmin(paketJasa, input);
                    break;
                case 0:
                    System.out.println("Terima Kasih Telah Menggunakan Aplikasi");
                    break;
                default:
                    System.out.println("Pilihan Tidak Valid");
                    break;
            }

        } while (choice != 0);
        input.close();
    }

    public static void modePengguna(PaketJasa paketJasa, Scanner input) {
        int choice;
        do {
            System.out.println("=================================");
            System.out.println("         MODE PENGGUNA           ");
            System.out.println("=================================");
            System.out.println("1. Masukkan Nama Anda Sebagai Pengirim ");
            System.out.println("2. Lihat Kiriman Sementara Antrian");
            System.out.println("3. Perbarui Data Yang Ingin Anda Masukkan");
            System.out.println("4. Kirim Paket Anda");
            System.out.println("0. Kembali ke Menu Utama");
            System.out.print("Pilihlah Operasi Dari Menu Diatas: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Masukkan Nama Anda: ");
                    input.nextLine();
                    String namaPengirim = input.nextLine();

                    System.out.print("Masukkan Nama Penerima: ");
                    String namaPenerima = input.nextLine();

                    System.out.print("Masukkan Alamat Penerima: ");
                    String namaAlamat = input.nextLine();

                    System.out.print("Masukkan Berat Barang: ");
                    double berat = input.nextDouble();

                    paketJasa.inputBarang(namaPengirim, namaPenerima, namaAlamat, 12000, berat);
                    break;
                case 2:
                    System.out.println("Berikut adalah data sementara yang bisa ditampilkan : ");
                    paketJasa.lihatSementara();
                    input.nextLine();
                    String lihatSementara1 = input.nextLine();
                    break;
              
                case 3:
                    System.out.print("Masukkan Nama Pengirim yang Akan Diupdate: ");
                    input.nextLine();
                    String updatePengirim = input.nextLine();

                    System.out.print("Masukkan Nama Penerima yang Akan Diupdate: ");
                    String updatePenerima = input.nextLine();

                    System.out.print("Masukkan Alamat yang Akan Diupdate: ");
                    String updateAlamat = input.nextLine();

                    paketJasa.updateBarang(updatePengirim, updatePenerima, updateAlamat);
                    break;
                case 4:
                    paketJasa.kirim();
                    input.nextLine();
                    String Terkirim = input.nextLine();
                    break;
                case 0:
                    System.out.println("Kembali ke Menu Utama");
                    break;
                default:
                    System.out.println("Pilihan Tidak Valid");
                    break;
            }

        } while (choice != 0);
    }

    public static void modeAdmin(PaketJasa paketJasa, Scanner input) {
        int choice;
        do {
            System.out.println("=================================");
            System.out.println("          MODE ADMIN             ");
            System.out.println("=================================");
            System.out.println("1. Lihat Kiriman Sementara Antrian");
            System.out.println("2. Hapus Barang Yang Ada Di Paket Barang");
            System.out.println("3. Perbarui Data Yang Ingin Anda Masukkan");
            System.out.println("4. Kirim Paket Anda");
            System.out.println("0. Kembali ke Menu Utama");
            System.out.print("Pilihlah Operasi Dari Menu Diatas: ");
            choice = input.nextInt();

            switch (choice) {
               
                case 1:
                    System.out.println("Berikut adalah data sementara yang bisa ditampilkan : ");
                    paketJasa.lihatSementara();
                    input.nextLine();
                    String lihatSementara1 = input.nextLine();
                    break;
                case 2:
                    System.out.print("Masukkan Nama Pengirim yang Akan Dihapus: ");
                    input.nextLine();
                    String hapusPengirim = input.nextLine();

                    paketJasa.hapusBarang(hapusPengirim);
                    break;
                case 3:
                    System.out.print("Masukkan Nama Pengirim yang Akan Diupdate: ");
                    input.nextLine();
                    String updatePengirim = input.nextLine();

                    System.out.print("Masukkan Nama Penerima yang Akan Diupdate: ");
                    String updatePenerima = input.nextLine();

                    System.out.print("Masukkan Alamat yang Akan Diupdate: ");
                    String updateAlamat = input.nextLine();

                    paketJasa.updateBarang(updatePengirim, updatePenerima, updateAlamat);
                    break;
                case 4:
                    paketJasa.kirim();
                    input.nextLine();
                    String Terkirim = input.nextLine();
                    break;
                case 0:
                    System.out.println("Kembali ke Menu Utama");
                    break;
                default:
                    System.out.println("Pilihan Tidak Valid");
                    break;
            }

        } while (choice != 0);
    }
}